    @yield('name')
    Try this one

    @php
        use App\Models\AssessmentAccidentVehicle;

        $new = "Hello World";
    @endphp

    {{$new}}


