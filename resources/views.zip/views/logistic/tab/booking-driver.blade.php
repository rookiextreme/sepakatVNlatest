<form class="" id="frm_addon">
    <input type="hidden" name="section" value="addon">
    <div class="row">
        <div class="col-md-8">
            <div class="col-md-6">
                <label for="" class="form-label  text-dark">Odometer</label>
                <input type="text" name="tel_no" class="form-control" autocomplete="off"
                value="" >
            </div>
            <div class="col-md-6">
                <label for="" class="form-label  text-dark">Masa Tugas Selesai</label>
                <input type="text" name="tel_no" class="form-control" autocomplete="off"
                value="" >
            </div>
            <div class="col-md-6">
                <label for="" class="form-label  text-dark">Touch N Go</label>
                <input type="text" name="tel_no" class="form-control" autocomplete="off"
                value="" >
            </div>
            <div class="col-md-6">
                <label for="" class="form-label  text-dark">Minyak</label>
                <input type="text" name="tel_no" class="form-control" autocomplete="off"
                value="" >
            </div>
        </div>
    </div>

</form>


<script type="text/javascript">

    // function submit(data){
    //     parent.startLoading();
    //     $.post("{{route('vehicle.register.save')}}", data, function(result){
    //         window.location = result['url'];
    //     });
    // }

    $(document).ready(function(){



        });
    })

</script>
