<form class="" id="frm_addon">
    <input type="hidden" name="section" value="addon">
    <div class="row">
        <div class="col-md-8">
            Upload Surat arahan kerja

        </div>
    </div>

</form>


<script type="text/javascript">

    // function submit(data){
    //     parent.startLoading();
    //     $.post("{{route('vehicle.register.save')}}", data, function(result){
    //         window.location = result['url'];
    //     });
    // }

    $(document).ready(function(){



        });
    })

</script>
