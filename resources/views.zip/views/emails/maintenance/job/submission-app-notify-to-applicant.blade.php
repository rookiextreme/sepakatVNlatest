<!DOCTYPE html>
<html>

<head>
    <title>{{ $details['title'] }}</title>
</head>

<body>
    <p>{{$details['detail']->applicant_name}},</p>

    <p>Permohonan anda telah berjaya dihantar. Sila tunggu untuk pengesahan temujanji. </p>

    <p>Sekian,</p>

    <p>Terima kasih</p>

    <p>SPaKAT</p>
</body>

</html>
