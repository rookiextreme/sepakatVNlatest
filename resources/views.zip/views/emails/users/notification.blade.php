<!DOCTYPE html>
<html>
<head>
    <title>{{ $details['title'] }}</title>
</head>
<body>
    Assalamualaikum / Salam Sejahtera,<br/>

    <p>Sila tunggu email pengesahan daripada pegawai kami.</p>
   
    <p>Terima Kasih</p>
</body>
</html>