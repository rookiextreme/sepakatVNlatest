<!DOCTYPE html>
<html>
<head>
    <title>{{ $details['title'] }}</title>
</head>
<body>
    Assalamualaikum / Salam Sejahtera,<br/>
    <p>Harap maaf, akaun anda telah dibatalkan.</p>
    <p>Sebab : {{ $details['reason'] }}</p>
   
    <p>Terima Kasih</p>
</body>
</html>