<!DOCTYPE html>
<html>
<head>
    <title>{{ $details['title'] }}</title>
</head>
<body>
    Assalamualaikum / Salam Sejahtera,<br/>

    <p>Sila log masuk ke aplikasi Spakat untuk sahkan pendaftaran baru :</p>

    Sila <a href="{{ $details['url'] }}">Klik Pautan</a> ini.

    <p>Pengguna baru </p>
    <p> Nama : {{$details['fullname']}} </p>
   
    <p>Terima Kasih</p>
</body>
</html>