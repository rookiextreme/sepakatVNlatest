Tuan/Puan,

<p>
    {{-- Terdapat satu notis saman yang telah dihantar untuk tindakan tuan/puan selanjutnya. --}}
    Terdapat satu notis saman kenderaan milik cawangan tuan yang telah didaftarkan
    di dalam Sistem Aplikasi Pengerusi Kenderaan Atas Talian (SPaKAT) untuk
    tindakan tuan selanjutnya.
</p>

<p>
    Sila login ke dalam SPaKAT melalui pautan di bawah:
</p>

<p>
    Sila Klik <a href="{{ $details['url'] }}">di sini</a>
</p>


<p>SISTEM SPAKAT</p>
