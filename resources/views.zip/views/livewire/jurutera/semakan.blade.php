<div>
    {{-- Do your work, then step back. --}}
    
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr class="table-dark">
                        <th class="text-white">KOD</th>
                        <th class="text-white">HAK MILIK</th>
                        <th class="text-white">NO KENDERAAN</th>
                        <th class="text-white">CAWANGAN</th>
                        <th class="text-white">KATEGORI > SUB-KATEGORI</th>
                        <th class="text-white">STATUS REKOD</th>
                        <th class="text-white">TINDAKAN PENGESAHAN</th>

                    </tr>
                </thead>
                <tbody>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>
