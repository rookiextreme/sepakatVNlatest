<div>
    {{-- Success is as dangerous as failure. --}}
    <input type="text" wire:model="err" name="" class="form-control">
    {{$err}}
</div>
