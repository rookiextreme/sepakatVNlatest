@extends('layouts.guest-2')
@section('content')

        @livewire('auth.forgot-account')

@endsection
