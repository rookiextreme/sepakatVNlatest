@extends('auth.app')

@section('content')

@livewire('auth.activation.user')
@endsection