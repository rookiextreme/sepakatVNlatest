@extends('auth.app')

@section('content')

        @livewire('auth.daftar')
        {{-- @livewire('auth.form-test') --}}
@endsection
