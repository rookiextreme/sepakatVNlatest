@extends('dashboards.app')


@section('title', 'Pengesahan Pendaftaran Pengguna')
@section('subtitle', 'Sepintas lalu senarai kenderaan yang sedang didaftarkan')
    

@section('content')

    @livewire('dashboard.pengguna')

@endsection

