<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link href="{{asset('my-assets/css/cubixi.css')}}" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="spectitle">Coming Soon</div>
    <div class="spectitle">Searching : {{$search}}</div>
</body>
</html>