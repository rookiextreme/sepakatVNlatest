<div class="content">
    <div class="mytitle">@yield('title')</div>
    <div class="myexplain">@yield('subtitle')</div>
    <div class="dashboard-container">
        @yield('content')
    </div>
    
</div>