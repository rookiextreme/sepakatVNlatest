@extends('dashboards.app')


@section('title', 'Carta alir saman kenderaan')
@section('subtitle', '')
    

@section('content')

    @livewire('dashboard.saman.jurutera.carta-alir')

@endsection

