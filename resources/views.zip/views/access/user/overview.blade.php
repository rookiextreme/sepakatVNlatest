@extends('dashboards.app')


@section('title', 'Carta Alir Pendaftaran Pengguna')
@section('subtitle', 'Sepintas lalu senarai kenderaan yang sedang didaftarkan')
    

@section('content')

    @livewire('user.overview')

@endsection

